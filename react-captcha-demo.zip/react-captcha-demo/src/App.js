import ToggleCaptcha from './component';
import './assets/main.css'

const App = () => {
  return (
    <div className="App">
      <ToggleCaptcha />
    </div>
  );
}

export default App;

import { useState } from 'react';
import AliyunLogo from '../assets/aliyun.png';
import CaptchaA from "./CaptchaA";
import CaptchaB from "./CaptchaB";
import './index.css';

const ToggleCaptcha = () => {
    const [toggleCaptcha, setToggleCaptcha] = useState(true);
    return (
        <div className="container">
            <img alt="Aliyun logo" className="logo" src={AliyunLogo} width="125" height="125" />

            <div className="wrapper">
                <div>点击切换验证码实例</div>
                <div>
                    <div className={toggleCaptcha ? 'text-color' : ''} onClick={() => setToggleCaptcha(true)}>CaptchaA</div>
                    <div className={!toggleCaptcha ? 'text-color' : ''} onClick={() => setToggleCaptcha(false)}>CaptchaB</div>
                </div>
            </div>

            <div className="button">
                {toggleCaptcha ? <CaptchaA /> : <CaptchaB />}
            </div>
        </div>
    );
}

export default ToggleCaptcha;